<?php

    session_start();
    include("includes/functions.php");

    $pro = getpro();

    if (isset($_POST['rmvid'])) 
    {
        unset($_SESSION["cart"][$_POST['rmvid']]);
    }


    if (isset($_POST['update_qty'])) 
    {
        foreach ($_POST['quantities'] as $id => $qty) 
        {
             $qty = max(1, intval($qty));
             $_SESSION["cart"][$id] = $qty;
        }
    }
?>

<html>
<head>
    <title>Cart</title>
</head>
<body>
     <form method="post">
            <table border="1" cellpadding="10" align="center">
                <tr>
                    <td colspan="5" align="center"><h2>Shopping Cart</h2></td>
                </tr>
                
                
                <tr>
                     <td colspan="5" align="center"><?php if (empty($_SESSION["cart"])): ?>
                     <p>Your cart is empty</p></td>
                </tr>
                <tr>
                    <td colspan="5" align="center"><a href="proucts.php">Back to proucts</a></td>
                </tr>
                
    
            <?php else: ?>
       
                <tr>
                    <th>prouct</th>
                    <th>Price</th>
                    <th>Qty</th>
                    <th>Total</th>
                    <th>Action</th>
                </tr>
               
                <?php $grandtotal = 0; ?>
               
                <?php foreach ($_SESSION["cart"] as $id => $qty): ?>
                   
                   <?php
                        $p = $pro[$id];
                        $total = $p["price"] * $qty;
                        $grandtotal += $total;
                    ?>
                    <tr>
                        <td><?= $p["name"] ?></td>
                        <td><?= $p["price"] ?></td>
                        <td><input type="number" name="quantities[<?= $id ?>]" value="<?= $qty ?>" min="1"></td>
                        <td><?= $total ?></td>
                        <td><button type="submit" name="rmvid" value="<?= $id ?>">Remove</button></td>
                    </tr>
                    <?php endforeach; ?>
               
                    <tr>
                         <td colspan="3"><strong>Grand Total:</strong></td>
                         <td colspan="2"><?= $grandtotal ?></td>
                    </tr>

                    <tr>
                         <td colspan="5" align="center"><a href="proucts.php">Back to proucts</a></td>
                    </tr>
               
                    <tr>
                         <td colspan="5" align="center"><button type="submit" name="update_qty">Update Cart</button></td>
                    </tr>
            </table><br>
       </form>
       <?php endif; ?>
</body>
</html>
