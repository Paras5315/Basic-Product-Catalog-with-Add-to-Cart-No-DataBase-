<?php

    session_start();
    include("includes/functions.php");

    $products = getpro();

    if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["prodid"])) 
    {
             $id = $_POST["prodid"];
             $qty = isset($_POST["quan"]) ? max(1, intval($_POST["quan"])) : 1;
           
             if (!isset($_SESSION["cart"]))
             {
                $_SESSION["cart"] = [];
             }

             if (isset($_SESSION["cart"][$id])) 
             {
                 $_SESSION["cart"][$id] += $qty;
             } 
             else 
             {
                 $_SESSION["cart"][$id] = $qty;
             }
             header("location: cart.php");
             exit();
    }
?>

<html>
    <head>
         <title>Product Catalog</title>   
    </head>
<body>

    <form method="post">
    <table border="2" align="center">
         <tr>
            <td colspan="5" align="center"> <h3>Product Catalog</h3></td>
         </tr>
         <tr>
            <th>Image</th>
            <th>Name</th>
            <th>Price</th>
            <th>quan</th>
            <th>Add to Cart</th>
         </tr>
        
         <?php foreach ($products as $id => $p): ?>
         
            <div class="product">        
               <tr>
                <td><img src="<?= $p["image"] ?>" alt="<?= $p["name"] ?>" width="100" border="1"><br></td>
                <td><?= $p["name"] ?><br></td>
                <td><?= $p["price"] ?><br></td>
                <input type="hidden" name="prodid" value="<?= $id ?>">               
                <td> <input type="number" name="quan" value="1" min="1"> </td>
                <td> <button type="submit">Add to cart</button> </td>
               </tr>
            </div>
    </form>
    <?php endforeach; ?>
    <tr>
        <td colspan="5" align="center"><a href="cart.php">View Cart</a></td>
    </tr>
    </table>
</body>
</html>
