<?php
function getpro()
{
    return[
        1=>["name"=>"Mouse","price"=>500,"image"=>"\project root\includes\mouse.jpeg"],
        2=>["name"=>"Printer","price"=>7000,"image"=>"\project root\includes\printer.jpeg"],
        3=>["name"=>"charger","price"=>1000,"image"=>"\project root\includes\charger.jpeg"],
        4=>["name"=>"battery","price"=>2000,"image"=>"\project root\includes\bettery.jpeg"],
        5=>["name"=>"keyboard","price"=>700,"image"=>"\project root\includes\keyboard.jpeg"]
         ];
}
?>